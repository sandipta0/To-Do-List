import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Cloud } from 'lucide-react';
import { RootState } from '../../store';
import { updateWeather, setWeatherLoading, setWeatherError } from '../../store/slices/todoSlice';

const WeatherWidget = () => {
  const dispatch = useDispatch();
  const weather = useSelector((state: RootState) => state.todos.weather);

  useEffect(() => {
    const fetchWeather = async () => {
      dispatch(setWeatherLoading());
      try {
        const response = await fetch(
          `https://pro.openweathermap.org/data/2.5/forecast/climate?id=2643743&appid=ce199d6194aa78eae5ab4e1513b6c203`
        );
        const data = await response.json();
        dispatch(
          updateWeather({
            temperature: Math.round(data.main.temp),
            description: data.weather[0].description,
          })
        );
      } catch (error) {
        dispatch(setWeatherError('Failed to fetch weather data'));
      }
    };

    fetchWeather();
  }, [dispatch]);

  if (weather.loading) {
    return <div>Loading weather...</div>;
  }

  if (weather.error) {
    return <div>Error: {weather.error}</div>;
  }

  return (
    <div className="flex items-center space-x-2 bg-white p-4 rounded-lg shadow">
      <Cloud className="h-6 w-6 text-blue-500" />
      <div>
        <p className="text-lg font-semibold">
          {weather.temperature}°C
        </p>
        <p className="text-sm text-gray-600">
          {weather.description}
        </p>
      </div>
    </div>
  );
};

export default WeatherWidget;