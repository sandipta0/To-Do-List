import React from 'react';
import { useDispatch } from 'react-redux';
import { Trash2, Check } from 'lucide-react';
import { removeTodo, toggleTodo } from '../../store/slices/todoSlice';
import { Todo } from '../../types';

interface TodoItemProps {
  todo: Todo;
}

const TodoItem: React.FC<TodoItemProps> = ({ todo }) => {
  const dispatch = useDispatch();

  const priorityColors = {
    low: 'bg-green-100 text-green-800',
    medium: 'bg-yellow-100 text-yellow-800',
    high: 'bg-red-100 text-red-800',
  };

  return (
    <div className="flex items-center justify-between p-4 bg-white rounded-lg shadow">
      <div className="flex items-center space-x-4">
        <button
          onClick={() => dispatch(toggleTodo(todo.id))}
          className={`p-2 rounded-full ${
            todo.completed ? 'bg-green-500 text-white' : 'bg-gray-200'
          }`}
        >
          <Check className="h-4 w-4" />
        </button>
        <div>
          <p
            className={`text-lg ${
              todo.completed ? 'line-through text-gray-500' : 'text-gray-900'
            }`}
          >
            {todo.title}
          </p>
          <span
            className={`inline-block px-2 py-1 text-xs font-semibold rounded-full ${
              priorityColors[todo.priority]
            }`}
          >
            {todo.priority}
          </span>
        </div>
      </div>
      <button
        onClick={() => dispatch(removeTodo(todo.id))}
        className="p-2 text-red-600 hover:text-red-800"
      >
        <Trash2 className="h-5 w-5" />
      </button>
    </div>
  );
};

export default TodoItem;