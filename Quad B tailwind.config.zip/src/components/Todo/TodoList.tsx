import React from 'react';
import { useSelector } from 'react-redux';
import { RootState } from '../../store';
import TodoItem from './TodoItem';

const TodoList = () => {
  const todos = useSelector((state: RootState) => state.todos.todos);

  const sortedTodos = [...todos].sort((a, b) => {
    const priorityOrder = { high: 0, medium: 1, low: 2 };
    return priorityOrder[a.priority] - priorityOrder[b.priority];
  });

  return (
    <div className="space-y-4">
      {sortedTodos.map((todo) => (
        <TodoItem key={todo.id} todo={todo} />
      ))}
    </div>
  );
};

export default TodoList;