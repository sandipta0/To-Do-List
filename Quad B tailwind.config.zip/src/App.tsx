import React from 'react';
import { useSelector } from 'react-redux';
import { RootState } from './store';
import LoginForm from './components/Auth/LoginForm';
import TodoInput from './components/Todo/TodoInput';
import TodoList from './components/Todo/TodoList';
import WeatherWidget from './components/Weather/WeatherWidget';

function App() {
  const { isAuthenticated } = useSelector((state: RootState) => state.auth);

  if (!isAuthenticated) {
    return <LoginForm />;
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-4xl mx-auto py-8 px-4">
        <div className="space-y-8">
          <div className="flex justify-between items-start">
            <h1 className="text-3xl font-bold text-gray-900">Todo List</h1>
            <WeatherWidget />
          </div>
          <TodoInput />
          <TodoList />
        </div>
      </div>
    </div>
  );
}

export default App;