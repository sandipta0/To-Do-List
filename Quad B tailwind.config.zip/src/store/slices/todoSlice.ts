import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Todo, TodoState } from '../../types';

const initialState: TodoState = {
  todos: [],
  loading: false,
  error: null,
  weather: {
    temperature: null,
    description: null,
    loading: false,
    error: null,
  },
};

const todoSlice = createSlice({
  name: 'todos',
  initialState,
  reducers: {
    addTodo: (state, action: PayloadAction<Todo>) => {
      state.todos.push(action.payload);
    },
    removeTodo: (state, action: PayloadAction<string>) => {
      state.todos = state.todos.filter((todo) => todo.id !== action.payload);
    },
    toggleTodo: (state, action: PayloadAction<string>) => {
      const todo = state.todos.find((todo) => todo.id === action.payload);
      if (todo) {
        todo.completed = !todo.completed;
      }
    },
    updateWeather: (state, action: PayloadAction<{ temperature: number; description: string }>) => {
      state.weather.temperature = action.payload.temperature;
      state.weather.description = action.payload.description;
      state.weather.loading = false;
      state.weather.error = null;
    },
    setWeatherLoading: (state) => {
      state.weather.loading = true;
    },
    setWeatherError: (state, action: PayloadAction<string>) => {
      state.weather.loading = false;
      state.weather.error = action.payload;
    },
  },
});

export const {
  addTodo,
  removeTodo,
  toggleTodo,
  updateWeather,
  setWeatherLoading,
  setWeatherError,
} = todoSlice.actions;
export default todoSlice.reducer;